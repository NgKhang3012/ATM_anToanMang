﻿using System.Runtime.CompilerServices;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Microsoft.AspNetCore.Authentication.Cookies;
using Sustainsys.Saml2.AspNetCore2;
using Sustainsys.Saml2;
using System.Security.Cryptography.X509Certificates;
using System.Net;
using System.Net.Http;
using Microsoft.Extensions.Options;

var builder = WebApplication.CreateBuilder(args);

// Đọc cấu hình chứng chỉ từ appsettings.json
var certificateConfig = builder.Configuration.GetSection("Certificate");
var certPath = certificateConfig["Path"];
var certPassword = certificateConfig["Password"];
var useSSL = bool.Parse(certificateConfig["UseSSL"]);


if (useSSL && !string.IsNullOrEmpty(certPath))
{
    // Nạp chứng chỉ từ đường dẫn
    var certificate = new X509Certificate2(certPath, certPassword);

    builder.WebHost.ConfigureKestrel(options =>
    {
        options.ListenAnyIP(49774, listenOptions =>
        {
            listenOptions.UseHttps(certificate); // Gán HTTPS với chứng chỉ
        });
    });
}

// Add services to the container.
builder.Services.AddControllersWithViews();

builder.Services.AddAuthorization(options =>
{
    // By default, all incoming requests will be authorized according to the default policy.
    options.FallbackPolicy = null;
});

builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = CookieAuthenticationDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = OpenIdConnectDefaults.AuthenticationScheme;
    //options.DefaultChallengeScheme = Saml2Defaults.Scheme;
});

builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = "Cookies";
    options.DefaultChallengeScheme = "OpenIdConnect";

})

    .AddCookie("Cookies", options =>
    {
        options.Cookie.Name = "SharedAuthCookie"; // Tên cookie chung
        options.Cookie.SameSite = SameSiteMode.None; // Để cho phép chia sẻ cookie giữa các miền
        options.Cookie.Domain = ".nhom4.atm";      // Phạm vi domain dùng chung

        //meow meow
        //options.Cookie.HttpOnly = true;
       // options.Cookie.SecurePolicy = CookieSecurePolicy.Always;

        options.Events.OnValidatePrincipal = context =>
        {
            Console.WriteLine("Validating principal...");
            foreach (var claim in context.Principal.Claims)
            {
                Console.WriteLine($"Claim Type: {claim.Type}, Claim Value: {claim.Value}");
            }
            return Task.CompletedTask;
        };

    })
    .AddOpenIdConnect("OpenIdConnect", options =>
    {
        //options.ClientId = "bebe36fd-5101-4293-ab8c-331513972979";
        options.ClientId = "ec19d372-9a55-4381-ba79-e87bd968f1b8";
        //options.ClientId = "a0b8e58c-9626-4fe0-9c57-33361f304642";
        //options.ClientSecret = "hRWdr50T11SC3myLhk6PiRjsu3TYNsWYINlyGI-7";
        options.Authority = "https://fs.nhom4.atm/adfs/";
        options.SignedOutRedirectUri = "https://app1.nhom4.atm:49774/";
        options.ResponseType = "id_token";
        options.SaveTokens = true;
        options.CallbackPath = "/signin-oidc";

        // Custom events
        options.Events = new OpenIdConnectEvents
        {
            OnRedirectToIdentityProvider = context =>
            {
                // Kiểm tra trạng thái xác thực của người dùng
                if (!context.HttpContext.User.Identity.IsAuthenticated)
                {
                    // Chưa đăng nhập, check cookie hoac yêu cầu đăng nhập
                    if (context.HttpContext.Request.Cookies.ContainsKey("SharedAuthCookie"))
                    {
                        context.ProtocolMessage.Prompt = "none"; // Kiểm tra trạng thái SSO
                    }
                    else
                    {
                        context.ProtocolMessage.Prompt = "login"; // Yêu cầu đăng nhập
                    }
                }
                else
                {
                    // Đã đăng nhập, không yêu cầu đăng nhập lại
                    context.ProtocolMessage.Prompt = "none"; // Kiểm tra trạng thái SSO mà không yêu cầu đăng nhập lại
                }

                return Task.CompletedTask;
            },
            OnRedirectToIdentityProviderForSignOut = context =>
            {
                // Chuyển hướng tới ADFS để đăng xuất
                context.ProtocolMessage.PostLogoutRedirectUri = context.Request.Scheme + "://" + context.Request.Host + "/Home/Index"; // URI để chuyển hướng sau khi đăng xuất
                return Task.CompletedTask;
            },
            OnRemoteFailure = context =>
            {
                // Xử lý lỗi xác thực và chuyển hướng tới trang lỗi
                Console.WriteLine($"Authentication failed: {context.Failure?.Message}");
                context.HandleResponse();
                context.Response.Redirect("/Home/Error?errormessage=" + Uri.EscapeDataString(context.Failure?.Message ?? "Unknown error"));
                return Task.CompletedTask;
            }
        };

        // Bypass SSL validation if necessary (development only)
        options.BackchannelHttpHandler = new HttpClientHandler
        {
            ServerCertificateCustomValidationCallback = (message, cert, chain, errors) => true
        };
    })
    //.AddSaml2("Saml2", options =>
    //{
    //    options.SPOptions.EntityId = new Sustainsys.Saml2.Metadata.EntityId("https://app1.nhom4.atm:49774/");

    //    options.IdentityProviders.Add(
    //    new Sustainsys.Saml2.IdentityProvider(
    //    new Sustainsys.Saml2.Metadata.EntityId("http://fs.nhom4.atm/adfs/services/trust"), options.SPOptions)
    //    {
    //        MetadataLocation = "https://fs.nhom4.atm/FederationMetadata/2007-06/FederationMetadata.xml",
    //        AllowUnsolicitedAuthnResponse = true,
    //        LoadMetadata = true


    //    });

    //});
    //.AddCookie()
    .AddSaml2("Saml2", options =>
    {
        options.SPOptions.EntityId = new Sustainsys.Saml2.Metadata.EntityId("https://app1.nhom4.atm:49774/");

        options.IdentityProviders.Add(
            new Sustainsys.Saml2.IdentityProvider(
                new Sustainsys.Saml2.Metadata.EntityId("http://fs.nhom4.atm/adfs/services/trust"), options.SPOptions)
            {
                MetadataLocation = "https://fs.nhom4.atm/FederationMetadata/2007-06/FederationMetadata.xml",
                AllowUnsolicitedAuthnResponse = false,
                LoadMetadata = true,
                SingleLogoutServiceUrl = new Uri("https://fs.nhom4.atm/adfs/ls/?wa=wsignoutcleanup1.0"),
                
            });
        options.SPOptions.WantAssertionsSigned = true;
    });



builder.Services.AddRazorPages();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseDeveloperExceptionPage();
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();

app.Use(async (context, next) =>
{
    if (context.User.Identity != null && context.User.Identity.IsAuthenticated)
    {
        Console.WriteLine("User is authenticated. Claims:");
        foreach (var claim in context.User.Claims)
        {
            Console.WriteLine($"Claim Type: {claim.Type}, Claim Value: {claim.Value}");
        }
    }

    await next();
});
app.Use(async (context, next) =>
{
    context.Response.Headers["Cache-Control"] = "no-cache, no-store, must-revalidate";
    context.Response.Headers["Pragma"] = "no-cache";
    context.Response.Headers["Expires"] = "0";

    await next();
});


app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
