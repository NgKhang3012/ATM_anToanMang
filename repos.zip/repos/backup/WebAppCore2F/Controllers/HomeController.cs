﻿using System.Diagnostics;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using WebAppCore1.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authentication.OpenIdConnect;
using Sustainsys.Saml2.AspNetCore2;

namespace WebAppCore1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }


        public IActionResult Index()
        {
            if (User.Identity?.IsAuthenticated ?? false)
            {
                foreach (var claim in User.Claims)
                {
                    Console.WriteLine($"Claim Type: {claim.Type}, Claim Value: {claim.Value}");
                }
            }
            return View();
        }


        public IActionResult Privacy()
        {
            return View();
        }

        [HttpGet]
        [AllowAnonymous]
        public IActionResult Login()
        {
            return Challenge(new AuthenticationProperties
            {
                RedirectUri = Url.Action("Index", "Home")
            }, OpenIdConnectDefaults.AuthenticationScheme);
        }
        //public IActionResult LoginSAML2()
        //{
        //    if (User.Identity?.IsAuthenticated ?? false)
        //    {
        //        foreach (var claim in User.Claims)
        //        {
        //            Console.WriteLine($"Claim Type: {claim.Type}, Claim Value: {claim.Value}");
        //        }
        //    }
        //    return RedirectToAction("Index");
        //}

        public IActionResult LoginSAML2()
        {
            // Tạo đối tượng AuthenticationProperties với RedirectUri
            var properties = new AuthenticationProperties
            {
                RedirectUri = Url.Action("Index", "Home")
            };

            // Chuyển hướng đến handler của SAML2 để bắt đầu xác thực với ForceAuthn
            return Challenge(new AuthenticationProperties
            {
                RedirectUri = Url.Action("Index", "Home"),
                Items = { { "ForceAuthn", "true" } }  // Thêm tham số ForceAuthn
            }, "Saml2");
        }



        [HttpPost]
        [Authorize]
        public async Task<IActionResult> Logout()
        {
            // Danh sách cookie cần xóa
            var cookiesToDelete = new[] { "SharedAuthCookie" };
            foreach (var cookie in cookiesToDelete)
            {
                // Xóa cookie từ domain chính ".nhom4.atm"
                HttpContext.Response.Cookies.Delete(cookie, new CookieOptions
                {
                    Domain = ".nhom4.atm", // Đảm bảo domain là .nhom4.atm để xóa cookie trên tất cả subdomains
                    Path = "/", // Đảm bảo xóa cookie ở path gốc
                    Secure = true, // Nếu sử dụng HTTPS
                    //HttpOnly = true, // Đảm bảo cookie không thể bị truy cập qua JavaScript
                    SameSite = SameSiteMode.None // Để hỗ trợ cookie giữa các miền
                });
            }
            var cookiesToDelete1 = new[]{ "MSISAuth", "MSISAuth1" };
            foreach (var cookie in cookiesToDelete1)
            {
                // Xóa cookie từ domain chính ".nhom4.atm"
                HttpContext.Response.Cookies.Delete(cookie, new CookieOptions
                {
                    Domain = "fs.nhom4.atm", // Đảm bảo domain là .nhom4.atm để xóa cookie trên tất cả subdomains
                    Path = "/", // Đảm bảo xóa cookie ở path gốc
                    Secure = true, // Nếu sử dụng HTTPS
                    //HttpOnly = true, // Đảm bảo cookie không thể bị truy cập qua JavaScript
                    SameSite = SameSiteMode.None // Để hỗ trợ cookie giữa các miền
                });
            }
            // Đăng xuất khỏi cookie của ứng dụng
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

            // Đăng xuất khỏi OpenID Connect
            var oidcProperties = new AuthenticationProperties
            {
                RedirectUri = "/" // URI chuyển hướng sau khi logout thành công
            };
            await HttpContext.SignOutAsync(OpenIdConnectDefaults.AuthenticationScheme, oidcProperties);

            // Đăng xuất khỏi SAML2
            var samlProperties = new AuthenticationProperties
            {
                RedirectUri = "/" // URI chuyển hướng sau khi logout thành công
            };
            await HttpContext.SignOutAsync("Saml2", samlProperties);
            SignOut(samlProperties, CookieAuthenticationDefaults.AuthenticationScheme, Saml2Defaults.Scheme);
            // Chuyển hướng về trang chính sau khi đăng xuất
            
            return RedirectToAction("Index", "Home");
        }




        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

    }
}
